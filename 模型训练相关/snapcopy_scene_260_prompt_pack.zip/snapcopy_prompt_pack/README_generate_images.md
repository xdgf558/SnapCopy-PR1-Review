# SnapCopy Scene Image Prompt Pack

This pack contains 260 image-generation prompts: 13 labels × 20 prompts per label.

Labels:
breakfast, cafe, walking, street, travel, pet, outfit, fitness, sunset, home, work, food, unknown

Recommended split for this small pilot set:

- train: 14 images per label
- validation: 3 images per label
- test: 3 images per label

Important: this is a synthetic prompt pack, not a finished training dataset. The guide recommends real lifestyle photos first and AI-generated images only as a supplement. Use these prompts to fill early gaps, test the labeling pipeline, or create a small pilot dataset. For the final Create ML model, replace most images with real photos.

Files included:

- `snapcopy_scene_260_prompts.csv`: spreadsheet-friendly prompt list.
- `snapcopy_scene_260_prompts.jsonl`: script/API-friendly prompt list.
- `SnapCopySceneDataset/dataset/...`: empty folder structure matching Create ML labels and splits.
- `SnapCopySceneDataset/docs/dataset-labeling-template.csv`: review template for the planned images.

Quality rules for generated images:

1. Keep images realistic and slightly imperfect.
2. Avoid polished advertising style.
3. Avoid visible brand logos and readable text.
4. Do not use collages except for the `unknown` class.
5. After generating, manually delete images that look too artificial or visually overlap with another label.
6. Resize training copies so the long edge is 768 to 1280 px.
7. Use filenames exactly as provided in the CSV.

Suggested review flow:

1. Generate images from the prompts.
2. Save each image to the `target_path` listed in the CSV.
3. Review each image manually.
4. Delete duplicates or images with the wrong primary scene.
5. Replace weak AI images with real photos whenever possible.
