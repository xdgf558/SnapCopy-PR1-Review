#!/bin/zsh
set -e
mkdir -p SnapCopySceneDataset/originals
for split in train validation test; do
  for label in breakfast cafe walking street travel pet outfit fitness sunset home work food unknown; do
    mkdir -p "SnapCopySceneDataset/dataset/$split/$label"
  done
done
mkdir -p SnapCopySceneDataset/docs
echo "Folder structure created. Put generated images into the paths listed in snapcopy_scene_260_prompts.csv."
